import tkinter as tk
import functions as f

if __name__ == "__main__":
    root = tk.Tk()
    app = f.ObserverApp(root)
    root.mainloop()